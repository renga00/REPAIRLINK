package com.example.Reddrop.controller;

import com.example.Reddrop.Repository.DonorRepository;
import com.example.Reddrop.model.Donor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/donors")
@CrossOrigin(origins = "*")
public class DonorController {

    @Autowired
    private DonorRepository donorRepository;

    @GetMapping
    public List<Donor> getAllDonors() {
        return donorRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Donor> getDonorById(@PathVariable Long id) {
        Optional<Donor> donorOpt = donorRepository.findById(id);
        return donorOpt.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Donor> addDonor(
            @RequestParam String name,
            @RequestParam int age,
            @RequestParam String bloodgroup,
            @RequestParam String phonenumber,
            @RequestParam String location
    ) {
        Donor donor = new Donor();
        donor.setName(name);
        donor.setAge(age);
        donor.setBloodgroup(bloodgroup);
        donor.setPhonenumber(phonenumber);
        donor.setLocation(location);

        Donor savedDonor = donorRepository.save(donor);
        return ResponseEntity.ok(savedDonor);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Donor> updateDonor(@PathVariable Long id, @RequestBody Donor donorDetails) {
        return donorRepository.findById(id)
                .map(donor -> {
                    donor.setName(donorDetails.getName());
                    donor.setAge(donorDetails.getAge());
                    donor.setBloodgroup(donorDetails.getBloodgroup());
                    donor.setPhonenumber(donorDetails.getPhonenumber());
                    donor.setLocation(donorDetails.getLocation());
                    return ResponseEntity.ok(donorRepository.save(donor));
                }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteDonor(@PathVariable Long id) {
        return donorRepository.findById(id)
                .map(donor -> {
                    donorRepository.delete(donor);
                    return ResponseEntity.noContent().<Void>build();
                }).orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/search")
    public List<Donor> searchDonors(
            @RequestParam String bloodGroup,
            @RequestParam String location) {
        return donorRepository.findByBloodgroupIgnoreCaseAndLocationContainingIgnoreCase(bloodGroup, location);
    }
}
