package com.example.Reddrop.Repository;

import com.example.Reddrop.model.Consumer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ConsumerRepository extends JpaRepository<Consumer, Long> {
  
}
