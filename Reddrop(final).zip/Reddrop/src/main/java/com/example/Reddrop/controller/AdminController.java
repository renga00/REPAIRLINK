package com.example.Reddrop.controller;

import com.example.Reddrop.Repository.AdminRepository;
import com.example.Reddrop.Repository.DonorRepository;
import com.example.Reddrop.model.Admin;
import com.example.Reddrop.model.Donor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.*;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "*")
public class AdminController {

    @Autowired
    private AdminRepository adminRepo;

    @Autowired
    private DonorRepository donorRepo;

    // Admin login
    @PostMapping("/login")
    public ResponseEntity<Map<String, String>> login(@RequestBody Admin login) {
        return adminRepo.findByUsername(login.getUsername())
            .filter(u -> u.getPassword().equals(login.getPassword()))
            .map(u -> {
                Map<String, String> response = new HashMap<>();
                response.put("message", "Login successful");
                return ResponseEntity.ok(response);
            })
            .orElse(ResponseEntity.status(HttpStatus.UNAUTHORIZED).build());
    }

    // Get all donors
    @GetMapping("/all-donors")
    public ResponseEntity<List<Donor>> getAllDonors() {
        // Auto-unblock donors if their block period has expired
        List<Donor> donors = donorRepo.findAll();
        for (Donor donor : donors) {
            if ("Blocked".equals(donor.getStatus()) && donor.getBlockUntil() != null) {
                if (LocalDate.now().isAfter(donor.getBlockUntil())) {
                    donor.setStatus("Active");
                    donor.setBlockUntil(null);
                    donorRepo.save(donor);
                }
            }
        }
        return ResponseEntity.ok(donorRepo.findAll());
    }

    // Block donor for 3 months
    @PutMapping("/block-donor/{id}")
    public ResponseEntity<String> blockDonor(@PathVariable Long id) {
        Optional<Donor> donorOpt = donorRepo.findById(id);
        if (donorOpt.isPresent()) {
            Donor donor = donorOpt.get();
            donor.setStatus("Blocked");
            donor.setBlockUntil(LocalDate.now().plusMonths(3)); // Block for 3 months
            donorRepo.save(donor);
            return ResponseEntity.ok("Donor blocked for 3 months.");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Donor not found.");
        }
    }
 // ✅ Update donor details (including location)
    @PutMapping("/update-donor/{id}")
    public ResponseEntity<String> updateDonor(@PathVariable Long id, @RequestBody Donor updatedDonor) {
        Optional<Donor> donorOpt = donorRepo.findById(id);
        if (donorOpt.isPresent()) {
            Donor donor = donorOpt.get();

            donor.setName(updatedDonor.getName());
            donor.setBloodgroup(updatedDonor.getBloodgroup());
            donor.setPhonenumber(updatedDonor.getPhonenumber());
            donor.setLocation(updatedDonor.getLocation()); // ✅ Add location here

            donorRepo.save(donor);

            return ResponseEntity.ok("Donor updated successfully.");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Donor not found.");
        }
    }

    // Delete donor
    @DeleteMapping("/delete-donor/{id}")
    public ResponseEntity<String> deleteDonor(@PathVariable Long id) {
        if (donorRepo.existsById(id)) {
            donorRepo.deleteById(id);
            return ResponseEntity.ok("Donor deleted successfully.");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Donor not found.");
        }
    }
 // ✅ Get all active donors only (for consumer requests)
    @GetMapping("/active-donors")
    public ResponseEntity<List<Donor>> getActiveDonors() {
        List<Donor> donors = donorRepo.findByStatus("Active");
        return ResponseEntity.ok(donors);
    }

    // ✅ Get blood group counts (excluding blocked donors)
    @GetMapping("/active-blood-group-counts")
    public ResponseEntity<Map<String, Integer>> getActiveBloodGroupCounts() {
        List<Donor> donors = donorRepo.findByStatus("Active");
        Map<String, Integer> bloodCounts = new HashMap<>();

        for (Donor donor : donors) {
            String group = donor.getBloodgroup();
            bloodCounts.put(group, bloodCounts.getOrDefault(group, 0) + 1);
        }

        return ResponseEntity.ok(bloodCounts);
    }

    @PutMapping("/update-donation-date/{donorId}")
    public ResponseEntity<String> updateDonationDateAndBlock(@PathVariable Long donorId) {
        Optional<Donor> donorOptional = donorRepo.findById(donorId);
        if (donorOptional.isPresent()) {
            Donor donor = donorOptional.get();

            // ✅ Set today's date as last donation date
            donor.setLastDonationDate(LocalDate.now());

            // ✅ Block donor for 3 months
            donor.setStatus("Blocked");
            donor.setBlockUntil(LocalDate.now().plusMonths(3)); // add this field if needed

            donorRepo.save(donor);

            return ResponseEntity.ok("Donation date updated and donor blocked for 3 months.");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Donor not found.");
        }
    }

}
