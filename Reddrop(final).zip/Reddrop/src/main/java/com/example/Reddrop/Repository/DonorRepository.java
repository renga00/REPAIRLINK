package com.example.Reddrop.Repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.Reddrop.model.Donor;

public interface DonorRepository extends JpaRepository<Donor, Long> {
	List<Donor> findByBloodgroupIgnoreCaseAndLocationContainingIgnoreCaseAndStatus(
		    String bloodgroup, String location, String status);

    @Modifying
    @Query("UPDATE Donor d SET d.lastDonationDate = :date WHERE d.id = :donorId")
    void updateDonationDate(@Param("donorId") Long donorId, @Param("date") LocalDate date);
 // ✅ Get all donors with status Active
    List<Donor> findByStatus(String status);

	List<Donor> findByBloodgroupIgnoreCaseAndLocationContainingIgnoreCase(String bloodGroup, String location);

}
