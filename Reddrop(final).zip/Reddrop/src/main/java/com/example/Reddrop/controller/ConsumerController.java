package com.example.Reddrop.controller;

import com.example.Reddrop.model.Consumer;
import com.example.Reddrop.model.Donor;
import com.example.Reddrop.Repository.ConsumerRepository;
import com.example.Reddrop.Repository.DonorRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/consumers")
@CrossOrigin(origins = "*")
public class ConsumerController {

    @Autowired
    private ConsumerRepository consumerRepository;

    @Autowired
    private DonorRepository donorRepository;

    @PostMapping("/request")
    public List<Donor> submitRequestAndFindDonors(@RequestBody Consumer consumer) {
        // Save consumer request
        consumerRepository.save(consumer);

        // Find matching donors with status ACTIVE
        List<Donor> matchingDonors = donorRepository
                .findByBloodgroupIgnoreCaseAndLocationContainingIgnoreCaseAndStatus(
                        consumer.getBloodGroup(),
                        consumer.getLocation(),
                        "Active" // ✅ Only Active donors
                );

        return matchingDonors;
    }

}
