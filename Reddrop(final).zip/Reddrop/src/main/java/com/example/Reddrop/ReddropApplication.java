package com.example.Reddrop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReddropApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReddropApplication.class, args);
	}

}
